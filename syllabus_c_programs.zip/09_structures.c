#include <stdio.h>
struct Student {
    char name[20];
    int age;
};
int main() {
    struct Student s1 = {"Alice", 20};
    printf("Name: %s\nAge: %d\n", s1.name, s1.age);
    return 0;
}