#include <stdio.h>
int main() {
    FILE *fptr = fopen("test.txt", "w");
    if (fptr != NULL) {
        fprintf(fptr, "Hello File!\n");
        fclose(fptr);
        printf("Data written to file.\n");
    } else {
        printf("Failed to open file.\n");
    }
    return 0;
}