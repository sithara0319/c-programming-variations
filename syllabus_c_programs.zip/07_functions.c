#include <stdio.h>
void greet() {
    printf("Hello from function!\n");
}
int main() {
    greet();
    return 0;
}