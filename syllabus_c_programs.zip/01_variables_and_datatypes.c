#include <stdio.h>
int main() {
    int age = 20;
    float height = 5.9;
    char grade = 'A';
    printf("Age: %d\nHeight: %.1f\nGrade: %c\n", age, height, grade);
    return 0;
}